<?php

namespace App\Http\Controllers;

use App\Models\Movie;
use Illuminate\Http\Request;

class MovieController extends Controller
{
    public function getMovie (){
        return response()->json(movie::all(),200);
    }

    public function intsertMovie(Request $request){
        $categoria = movie::create($request->all());
        return response($categoria,200);
    }

    public function upMovie(Request $request, $id){
        $movie = movie::find($id);
        $movie->update($request->all());
        return response($movie,200);
    }

    public function delMovie($id){
        $categoria= movie::find($id);
        $categoria->delete();
        return response()->json(['Mensaje'=>'Se elmino'],200);
    }
}
