<?php

namespace App\Http\Livewire;

use Livewire\Component;
use Livewire\WithPagination;
use App\Models\Movie;

class Movies extends Component
{
    use WithPagination;

	protected $paginationTheme = 'bootstrap';
    public $selected_id, $keyWord, $pelicula, $descripcion, $precio;
    public $updateMode = false;

    public function render()
    {
		$keyWord = '%'.$this->keyWord .'%';
        return view('livewire.movies.view', [
            'movies' => Movie::latest()
						->orWhere('pelicula', 'LIKE', $keyWord)
						->orWhere('descripcion', 'LIKE', $keyWord)
						->orWhere('precio', 'LIKE', $keyWord)
						->paginate(10),
        ]);
    }
	
    public function cancel()
    {
        $this->resetInput();
        $this->updateMode = false;
    }
	
    private function resetInput()
    {		
		$this->pelicula = null;
		$this->descripcion = null;
		$this->precio = null;
    }

    public function store()
    {
        $this->validate([
		'pelicula' => 'required',
		'descripcion' => 'required',
		'precio' => 'required',
        ]);

        Movie::create([ 
			'pelicula' => $this-> pelicula,
			'descripcion' => $this-> descripcion,
			'precio' => $this-> precio
        ]);
        
        $this->resetInput();
		$this->emit('closeModal');
		session()->flash('message', 'Movie Successfully created.');
    }

    public function edit($id)
    {
        $record = Movie::findOrFail($id);

        $this->selected_id = $id; 
		$this->pelicula = $record-> pelicula;
		$this->descripcion = $record-> descripcion;
		$this->precio = $record-> precio;
		
        $this->updateMode = true;
    }

    public function update()
    {
        $this->validate([
		'pelicula' => 'required',
		'descripcion' => 'required',
		'precio' => 'required',
        ]);

        if ($this->selected_id) {
			$record = Movie::find($this->selected_id);
            $record->update([ 
			'pelicula' => $this-> pelicula,
			'descripcion' => $this-> descripcion,
			'precio' => $this-> precio
            ]);

            $this->resetInput();
            $this->updateMode = false;
			session()->flash('message', 'Movie Successfully updated.');
        }
    }

    public function destroy($id)
    {
        if ($id) {
            $record = Movie::where('id', $id);
            $record->delete();
        }
    }
}
