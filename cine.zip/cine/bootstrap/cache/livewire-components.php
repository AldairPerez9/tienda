<?php return array (
  'movies' => 'App\\Http\\Livewire\\Movies',
);